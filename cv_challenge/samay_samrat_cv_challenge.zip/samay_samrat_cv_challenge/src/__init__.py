# CV Challenge Pipeline source
